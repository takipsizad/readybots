const express = require('express');
const { Client, MessageEmbed } = require('discord.js-selfbot');
const app = express();
    function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  } //test
}
const http = require('http');
app.get("/", (request, response) => {
  console.log(Date.now() + " Hostlandı");
  response.sendStatus(200);
});
app.listen(process.env.PORT);
setInterval(() => {
  http.get(`http://${process.env.PROJECT_DOMAIN}.glitch.me/`);
}, 280000) 
const Discord = require('discord.js-selfbot');
const client = new Discord.Client();
const data = new Map();

client.on('ready', () => {
        console.log(`${client.user.username} ismi ile giriş yapıldı! ${client.guilds.size} Sunucu, ${client.users.size} Kullanıcı.`);
});
    let sent = [];
client.on("message", async msg => {
  if (msg.channel.type === "dm") {
    

    if (msg.author.id === client.user.id) {
    } else {
      if (msg.author.bot) {
      } else {
        let fyukas = await data.get(msg.author.id)
        
        if (fyukas === 1) {
        } else {
          
          if(sent.includes(msg.author.id)) return;
          sent.push(msg.author.id)
           msg.channel.startTyping();
          await sleep(10000)
          
          await msg.channel.send("https://discord.gg/hBdpT3VSgn") // Discord sunucunuzun kalıcı linkini girin size mesaj atanlara oto dönüş yapması için.
          await msg.channel.stopTyping();
          await sleep(30000)
          msg.channel.startTyping();
          await msg.channel.send("**Can you please stay in tokyo daddy <3**")
          await msg.channel.stopTyping();
          
          
      }
      }
    }
  }
})


client.on("guildCreate", rachecode => {

  });




client.on("ready", () => {
      setInterval(() => {
       let a = client.channels.cache.get("865199581201301534") // j4j sunucusunun kanal id'si


       a.send("J4J Dm Non-Bots Come! (J4J Dm Bot Olmayanlar Gelsin!")


      }, 300);
})



client.on("ready", () => {
      setInterval(() => {
       let a = client.channels.cache.get("855531331304030240") // j4j sunucusunun kanal id'si


       a.send("J4J Dm Non-Bots Come! (J4J Dm Bot Olmayanlar Gelsin!")


      }, 300);
})





client.on("ready", () => {
      setInterval(() => {
       let a = client.channels.cache.get("849388403564609547") // j4j sunucusunun kanal id'si


       a.send("J4J Dm Non-Bots Come! (J4J Dm Bot Olmayanlar Gelsin!")


      }, 50);
})

client.on("ready", () => {
      setInterval(() => {
       let a = client.channels.cache.get("821085472436518933") // j4j sunucusunun kanal id'si


       a.send("J4J Dm Non-Bots Come! (J4J Dm Bot Olmayanlar Gelsin!")


      }, 300);
})

client.on("ready", () => {
      setInterval(() => {
       let a = client.channels.cache.get("801533098784849930") // j4j sunucusunun kanal id'si


       a.send("J4J Dm Non-Bots Come! (J4J Dm Bot Olmayanlar Gelsin!")


      }, 300);
})

client.on("ready", () => {
      setInterval(() => {
       let a = client.channels.cache.get("653186220020465665") // j4j sunucusunun kanal id'si


       a.send("J4J Dm Non-Bots Come! (J4J Dm Bot Olmayanlar Gelsin!")


      }, 300);
})



client.login("ODg3MzY5MTk4MTA2NDY4Mzky.YUDI-g.6uTI0pH8nSChyHvn2RaqL9jbILs") // user tokeniniz

